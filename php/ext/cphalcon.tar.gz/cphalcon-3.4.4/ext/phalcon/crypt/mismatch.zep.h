
extern zend_class_entry *phalcon_crypt_mismatch_ce;

ZEPHIR_INIT_CLASS(Phalcon_Crypt_Mismatch);

